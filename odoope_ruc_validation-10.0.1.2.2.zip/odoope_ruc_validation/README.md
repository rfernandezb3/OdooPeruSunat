Validador RUC y DNI
===================

Clientes y Proveedores:
-----------------------
    * Nuevo campo "tipo de documento"
    * Validacion RUC y DNI

Dependencias:
-------------
$ sudo apt-get install tesseract-ocr tesseract-ocr-eng python-imaging python-pip python-bs4
$ sudo pip install pytesseract

Créditos:
---------
Este módulo esta basado en el módulo de Alex Cuellar en https://github.com/alexcuellar/l10n_pe_doc_validation
